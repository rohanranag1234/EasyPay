import { Response } from "express";
import { prisma } from "../config/prisma";
import { AuthRequest } from "../middleware/auth";
import { banks, calculate, confirmSchema, quoteSchema, recipientError } from "../domain/bridgepay";

function quoteDto(q: any) {
  return { id: q.id, createdAt: q.createdAt.toISOString(), expiresAt: q.expiresAt.toISOString(), amount: Number(q.amount), from: q.fromCurrency, to: q.toCurrency, rate: Number(q.rate), platformFee: Number(q.platformFee), bankFee: Number(q.bankFee), promoDiscount: Number(q.promoDiscount), totalCost: Number(q.totalCost), receiveAmount: Number(q.receiveAmount), promo: q.promo, fromBank: q.fromBank, toBank: q.toBank, recipient: { name: q.recipientName, account: q.recipientAccount, code: q.recipientCode, save: false } };
}
function transferDto(t: any) {
  const statuses: Record<string, string> = { PAYMENT_PENDING: "Processing", PAYMENT_RECEIVED: "Processing", COMPLIANCE_CHECK: "Processing", PROCESSING: "Processing", SENT: "Processing", COMPLETED: "Completed", FAILED: "Failed", CANCELLED: "Failed", REFUNDED: "Failed" };
  return { id: t.id, quote: quoteDto(t.quote), status: statuses[t.status] || "Processing", rawStatus: t.status, createdAt: t.createdAt.toISOString(), ...(t.completedAt ? { completedAt: t.completedAt.toISOString() } : {}) };
}
export async function getConfig(_req: AuthRequest, res: Response) {
  return res.json({ currencies: ["JPY", "USD", "EUR", "GBP", "INR"], sendingCurrencies: ["JPY", "USD", "EUR", "GBP"], banks, mode: "demo", ratesAreLive: false });
}
export async function createQuote(req: AuthRequest, res: Response) {
  const data = quoteSchema.parse(req.body);
  const fromBank = banks[data.from].find(b => b.name === data.fromBank);
  const toBank = banks[data.to].find(b => b.name === data.toBank);
  if (!fromBank || !toBank) return res.status(400).json({ error: "Select valid sending and receiving banks." });
  const issue = recipientError(data.recipient, data.to);
  if (issue) return res.status(400).json({ error: issue });
  const calc = calculate({ amount: data.amount, from: data.from, to: data.to, bankFee: fromBank.fee, promo: data.promo });
  const expiresAt = new Date(Date.now() + 30 * 60 * 1000);
  const quote = await prisma.quote.create({ data: { userId: req.user!.userId, fromCurrency: data.from, toCurrency: data.to, amount: calc.amount, rate: calc.rate, platformFee: calc.platformFee, bankFee: calc.bankFee, promoDiscount: calc.promoDiscount, totalCost: calc.totalCost, receiveAmount: calc.receiveAmount, fromBank: data.fromBank, toBank: data.toBank, recipientName: data.recipient.name.trim(), recipientAccount: data.recipient.account, recipientCode: data.recipient.code.toUpperCase(), promo: data.promo, expiresAt } });
  return res.status(201).json({ quote: quoteDto(quote) });
}
export async function confirmTransfer(req: AuthRequest, res: Response) {
  const data = confirmSchema.parse(req.body);
  const existing = await prisma.transfer.findUnique({ where: { idempotencyKey: data.idempotencyKey }, include: { quote: true } });
  if (existing) {
    if (existing.userId !== req.user!.userId) return res.status(409).json({ error: "Idempotency key already used" });
    return res.json({ transfer: transferDto(existing), idempotent: true });
  }
  const quote = await prisma.quote.findFirst({ where: { id: data.quoteId, userId: req.user!.userId } });
  if (!quote) return res.status(404).json({ error: "Quote not found" });
  if (quote.expiresAt.getTime() <= Date.now()) return res.status(400).json({ error: "This quote has expired. Please refresh your quote." });
  const created = await prisma.$transaction(async tx => {
    let recipientId: string | undefined;
    if (data.saveRecipient) {
      const recipient = await tx.recipient.create({ data: { userId: req.user!.userId, name: quote.recipientName, currency: quote.toCurrency, bankName: quote.toBank, accountNumber: quote.recipientAccount, bankCode: quote.recipientCode } });
      recipientId = recipient.id;
    }
    const transfer = await tx.transfer.create({ data: { userId: req.user!.userId, quoteId: quote.id, recipientId, idempotencyKey: data.idempotencyKey, status: "PAYMENT_PENDING" }, include: { quote: true } });
    await tx.transferEvent.create({ data: { transferId: transfer.id, type: "CREATED", toStatus: "PAYMENT_PENDING", metadata: { source: "mobile-app", mode: "demo" } } });
    return transfer;
  });
  return res.status(201).json({ transfer: transferDto(created), idempotent: false });
}
export async function listTransfers(req: AuthRequest, res: Response) {
  const transfers = await prisma.transfer.findMany({ where: { userId: req.user!.userId }, include: { quote: true }, orderBy: { createdAt: "desc" } });
  return res.json({ transfers: transfers.map(transferDto) });
}
export async function getTransfer(req: AuthRequest, res: Response) {
  const transfer = await prisma.transfer.findFirst({ where: { id: req.params.id, userId: req.user!.userId }, include: { quote: true, events: { orderBy: { createdAt: "asc" } } } });
  if (!transfer) return res.status(404).json({ error: "Transfer not found" });
  return res.json({ transfer: { ...transferDto(transfer), events: transfer.events } });
}
