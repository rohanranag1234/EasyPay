import { Request, Response, NextFunction } from "express";
import { ZodError } from "zod";
export function asyncHandler(fn: (req: any, res: Response, next: NextFunction) => Promise<unknown>) {
  return (req: Request, res: Response, next: NextFunction) => Promise.resolve(fn(req, res, next)).catch(next);
}
export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction) {
  if (err instanceof ZodError) return res.status(400).json({ error: "Validation failed", details: err.issues.map(i => ({ path: i.path.join("."), message: i.message })) });
  if (err instanceof Error && err.message.startsWith("APP:")) return res.status(400).json({ error: err.message.slice(4) });
  console.error(err); return res.status(500).json({ error: "Internal server error" });
}
