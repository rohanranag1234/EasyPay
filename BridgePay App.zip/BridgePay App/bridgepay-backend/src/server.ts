import { app } from "./app";
import { env } from "./config/env";
import { prisma } from "./config/prisma";
const server = app.listen(env.PORT, () => console.log(`BridgePay API listening on http://localhost:${env.PORT}`));
async function shutdown() { server.close(async () => { await prisma.$disconnect(); process.exit(0); }); }
process.on("SIGINT", shutdown); process.on("SIGTERM", shutdown);
