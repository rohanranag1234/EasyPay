# BridgePay Backend (starter)

Backend starter aligned to the uploaded BridgePay Expo app's data model and prototype calculation rules. It includes Express + TypeScript, PostgreSQL + Prisma, JWT auth, recipients, persistent quotes, transfers, and transfer-event audit records.

> **Demo only.** FX rates are the static sample values from the current app (`src/domain/calc.js`). Confirming a transfer creates a database record with `PAYMENT_PENDING`; it does not charge a bank account or send money. Do not use this project for real customer funds. Real remittance requires a licensed/authorized provider, verified webhooks, KYC/AML and jurisdiction-specific compliance, security review, reconciliation, and production operations.

## Requirements
- Node.js 20+
- Docker Desktop (or a PostgreSQL 15+ server)

## Setup
```bash
cp .env.example .env
# Change JWT_SECRET to a random secret of at least 32 characters.
docker compose up -d
npm install
npx prisma generate
npx prisma migrate dev --name init
npm run dev
```
Health check: `GET http://localhost:4000/health`

## API
All JSON responses use standard HTTP status codes. Except register/login/config/health, endpoints require `Authorization: Bearer <token>`.

- `POST /api/auth/register` `{ "name":"Rohan Rana", "email":"rohan@example.com", "mobile":"+81...", "password":"a-long-password" }`
- `POST /api/auth/login` `{ "email":"rohan@example.com", "password":"a-long-password" }`
- `GET /api/auth/me`
- `GET /api/transfers/config` returns supported currencies/banks and declares that FX is demo-only
- `POST /api/recipients` `{ "name":"Sample Parent", "currency":"INR", "bankName":"HDFC Bank", "account":"123456789012", "code":"HDFC0001234" }`
- `GET /api/recipients`
- `DELETE /api/recipients/:id`
- `POST /api/transfers/quote` `{ "amount":"100000", "from":"JPY", "to":"INR", "fromBank":"JP Bank", "toBank":"HDFC Bank", "promo":true, "recipient":{"name":"Sample Parent","account":"123456789012","code":"HDFC0001234"} }`
- `POST /api/transfers/confirm` `{ "quoteId":"<quote id>", "idempotencyKey":"unique-transfer-key-0001", "saveRecipient":true }`
- `GET /api/transfers`
- `GET /api/transfers/:id`

## Connect the Expo app
Set an API base URL in your app configuration, e.g. `EXPO_PUBLIC_API_URL=http://YOUR_COMPUTER_LAN_IP:4000`. A simulator/device cannot usually reach the development computer via `localhost`; use the computer's LAN IP on the same network or an HTTPS dev tunnel. On iOS Simulator, `localhost` may work depending on setup.

Replace calls to `demoService.createQuote(draft)` with an authenticated `POST /api/transfers/quote`, and replace `demoService.confirm(quote)` with `POST /api/transfers/confirm`. The returned quote DTO retains the app's fields (`amount`, `from`, `to`, `rate`, `platformFee`, `bankFee`, `promoDiscount`, `totalCost`, `receiveAmount`, `promo`, `fromBank`, `toBank`, `recipient`, `createdAt`, `expiresAt`). Persist the token securely on-device (e.g. Expo SecureStore), not in source code.

## Before production
- Replace sample FX and bank fees with provider-sourced, timestamped quotes.
- Use a licensed/authorized remittance/payment provider for money movement.
- Add email/SMS OTP with real provider integration; current verified flags are not a verification flow.
- Encrypt sensitive recipient/bank data at rest; consider tokenization/provider-hosted beneficiary collection.
- Add signed webhook verification, replay protection, reconciliation, refunds, stronger audit controls, monitoring, and a reviewed state-transition policy.
- Add formal integration tests and CI; conduct security and legal review for Japan and India.
